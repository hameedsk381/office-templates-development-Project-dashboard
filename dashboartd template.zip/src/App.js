import { Box} from "@mui/material";
import BodyComp from "./components/BodyComp";

import SidebarComp from "./components/SidebarComp";


function App() {
  return (
    <Box sx={{display:"flex"}}>
<SidebarComp/>
<BodyComp/>
  
    </Box>
  );
}

export default App;
