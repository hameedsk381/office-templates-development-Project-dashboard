## Template

![output](https://user-images.githubusercontent.com/118173148/208615268-8483fff8-d636-42cc-93a9-5b7672e9234e.png)

## Component

- Box - 5
- AppBar- 1
- Toolbar - 1
- Avatar - 1
- Stack - 23
- Typography - 21
- Button - 11
- Card - 6
- IconButton - 1
- Grid - 6
- Accordion - 2
- AccordionSummary - 2
